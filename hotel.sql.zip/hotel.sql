-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 17, 2018 at 01:09 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usname` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `usname`, `pass`) VALUES
(2, 'krish', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(5) DEFAULT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `troom` varchar(30) DEFAULT NULL,
  `tbed` varchar(30) DEFAULT NULL,
  `nroom` int(11) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `ttot` double(8,2) DEFAULT NULL,
  `fintot` double(8,2) DEFAULT NULL,
  `mepr` double(8,2) DEFAULT NULL,
  `meal` varchar(30) DEFAULT NULL,
  `btot` double(8,2) DEFAULT NULL,
  `noofdays` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `title`, `fname`, `lname`, `troom`, `tbed`, `nroom`, `cin`, `cout`, `ttot`, `fintot`, `mepr`, `meal`, `btot`, `noofdays`) VALUES
(2, 'Mr.', 'Kirshanu', 'Chakraborty', 'Superior Room', 'Quad', 5, '2018-02-03', '2018-03-17', 67200.00, 69888.00, 2150.40, 'Full Board', 537.60, 42),
(3, 'Dr.', 'Ujjayani', 'Sahoo', 'Deluxe Room', 'Double', 3, '2018-03-01', '2018-03-03', 1320.00, 1346.40, 17.60, 'Breakfast', 8.80, 2),
(4, 'Miss.', 'Mahadhriti', 'Ghosh', 'Guest House', 'Single', 1, '2018-04-04', '2018-04-08', 720.00, 741.60, 14.40, 'Breakfast', 7.20, 4),
(5, 'Mr.', 'Sourav', 'Chatterjee', 'Superior Room', 'Single', 2, '2018-04-20', '2018-04-29', 5760.00, 5846.40, 57.60, 'Breakfast', 28.80, 9),
(6, 'Mr.', 'lATOON', 'SAHOO', 'Deluxe Room', 'Double', 1, '2018-04-08', '2018-04-19', 2420.00, 2565.20, 96.80, 'Breakfast', 48.40, 11),
(7, 'Mr.', 'Rajdeep', 'Roy', 'Superior Room', 'Double', 4, '0000-00-00', '2018-04-15', 0.00, 0.00, 0.00, 'Breakfast', 0.00, 0),
(8, 'Mr.', 'Arjak', 'Majundar', 'Superior Room', 'Single', 2, '2018-04-10', '2018-04-11', 640.00, 652.80, 9.60, 'Half Board', 3.20, 1),
(9, 'Mr.', 'Anutam', 'Puitandi', 'Superior Room', 'Quad', 7, '2018-06-27', '2019-07-27', 884800.00, 910080.00, 20224.00, 'Full Board', 5056.00, 395);

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE IF NOT EXISTS `room` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(15) DEFAULT NULL,
  `bedding` varchar(10) DEFAULT NULL,
  `place` varchar(10) DEFAULT NULL,
  `cusid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `type`, `bedding`, `place`, `cusid`) VALUES
(1, 'Superior Room', 'Single', 'NotFree', 8),
(2, 'Superior Room', 'Double', 'NotFree', 7),
(3, 'Superior Room', 'Triple', 'Free', NULL),
(4, 'Single Room', 'Quad', 'Free', NULL),
(5, 'Superior Room', 'Quad', 'NotFree', 9),
(6, 'Deluxe Room', 'Single', 'Free', NULL),
(7, 'Deluxe Room', 'Double', 'NotFree', 6),
(8, 'Deluxe Room', 'Triple', 'Free', NULL),
(9, 'Deluxe Room', 'Quad', 'Free', NULL),
(10, 'Guest House', 'Single', 'NotFree', 4),
(11, 'Guest House', 'Double', 'Free', NULL),
(12, 'Guest House', 'Quad', 'Free', NULL),
(14, 'Single Room', 'Double', 'Free', NULL),
(15, 'Single Room', 'Triple', 'Free', NULL),
(16, 'Superior Room', 'Single', 'Free', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roombook`
--

CREATE TABLE IF NOT EXISTS `roombook` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `Title` varchar(5) DEFAULT NULL,
  `FName` text,
  `LName` text,
  `Email` varchar(50) DEFAULT NULL,
  `National` varchar(30) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL,
  `Phone` text,
  `TRoom` varchar(20) DEFAULT NULL,
  `Bed` varchar(10) DEFAULT NULL,
  `NRoom` varchar(2) DEFAULT NULL,
  `Meal` varchar(15) DEFAULT NULL,
  `cin` date DEFAULT NULL,
  `cout` date DEFAULT NULL,
  `stat` varchar(15) DEFAULT NULL,
  `nodays` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `roombook`
--

INSERT INTO `roombook` (`id`, `Title`, `FName`, `LName`, `Email`, `National`, `Country`, `Phone`, `TRoom`, `Bed`, `NRoom`, `Meal`, `cin`, `cout`, `stat`, `nodays`) VALUES
(2, 'Mr.', 'Kirshanu', 'Chakraborty', 'shanu.16k@gmail.com', 'Indian', 'India', '9547915974', 'Superior Room', 'Quad', '5', 'Full Board', '2018-02-03', '2018-03-17', 'Conform', 42),
(4, 'Miss.', 'Mahadhriti', 'Ghosh', 'go4mhahi@gmail.com', 'Indian', 'India', '675767654', 'Guest House', 'Single', '1', 'Breakfast', '2018-04-04', '2018-04-08', 'Conform', 4),
(5, 'Mr.', 'Sourav', 'Chatterjee', 'sou@gmail.com', 'Indian', 'India', '789456123', 'Superior Room', 'Single', '2', 'Breakfast', '2018-04-20', '2018-04-29', 'Conform', 9),
(6, 'Mr.', 'lATOON', 'SAHOO', 'LS@GMAIL.COM', 'Indian', 'India', '12345', 'Deluxe Room', 'Double', '1', 'Breakfast', '2018-04-08', '2018-04-19', 'Conform', 11),
(7, 'Mr.', 'Rajdeep', 'Roy', 'rr@gmail.com', 'Indian', 'India', '123456', 'Superior Room', 'Double', '4', 'Breakfast', '0000-00-00', '2018-04-15', 'Conform', NULL),
(8, 'Mr.', 'Arjak', 'Majundar', 'a@gmail.com', 'Indian', 'India', '12466', 'Superior Room', 'Single', '2', 'Half Board', '2018-04-10', '2018-04-11', 'Conform', 1),
(9, 'Mr.', 'Anutam', 'Puitandi', 'anutampuitandi95@gmail.com', 'Non Indian ', 'Australia', '4021579632', 'Superior Room', 'Quad', '7', 'Full Board', '2018-06-27', '2019-07-27', 'Conform', 395);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'piyush', 'piyushchakraborty9@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(2, 'krish', 'shanu.16k@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(3, 'Mahi', 'go4mhahi@gmail.com', 'dda99de58ff020cfb57fec1404c97003'),
(4, 'sj', 'hdgd@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(5, 'swarup', 'sgs@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(6, 'piyush ch', 'p@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(7, 'sourav', 'sou@gmail.com', 'f12d650c07037239968148df384b1fcf'),
(8, 'latun sahoo', 'l@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(9, 'Rajdeep Roy', 'rr@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(10, 'arjak', 'a@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055'),
(11, 'Anutam', 'anutampuitandi95@gmail.com', 'c4edea25c6f78f66f312b069f9745883'),
(12, 'raja', 'raja@abc.com', '526e34d04735124f05a090181f3e6e8a');
